import java.util.Scanner;

public class BinarySearch {

	public int binary(int arr[],int f,int l,int key) {
		int mid;
		mid=(f+l)/2;
		if(f>mid||l<mid)
			return (-1);
		if(arr[mid]==key){
			return (mid+1);
		}
		if(arr[mid]<key)
			return binary(arr,mid+1,l,key);
		return binary(arr,f,mid-1,key);	

	}

	public void Insertion(int arr[])
	{
		int j,x;
		for(int i=1;i<arr.length;i++){
		x=arr[i];
			for(j=i-1;j>=0 && x<arr[j];j--){
				arr[j+1]=arr[j];
			}
		arr[j+1]=x;
		}
		
	}
	public static void main(String[] args) {
		int n,arr[];
		BinarySearch bs=new BinarySearch();
		System.out.print("Enter Number of Elements in Array:");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		arr=new int[n];
		for(int i=0;i<n;i++){
			arr[i]=sc.nextInt();
		}
		bs.Insertion(arr);
		
		char ch='Y';
		do{
			for(int i:arr){
				System.out.print(i+"\t");
			}
			System.out.println("\nEnter element to find:");
			int key=sc.nextInt();
			int pos = bs.binary(arr,0,n-1,key);
			if(pos==-1)
				System.out.println("Key "+key+" not found");
			else
				System.out.println("Key "+key+" found at postion "+pos);
			System.out.println("Do You want to Search again? (Y/N)");
			ch=sc.next(".").charAt(0);
		}
		while(ch=='Y'||ch=='y');
		sc.close();
	}
}

/* OUTPUT
Enter Number of Elements in Array:15
18
15
16
12
13
14
17
10
3
1
0
56
98
24
65
0	1	3	10	12	13	14	15	16	17	18	24	56	65	98	
Enter element to find:
55
Key 55 not found
Do You want to Search again? (Y/N)
y
0	1	3	10	12	13	14	15	16	17	18	24	56	65	98	
Enter element to find:
56
Key 56 found at postion 13
Do You want to Search again? (Y/N)
n*/
