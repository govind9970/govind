#include<iostream>
#include<omp.h>
using namespace std;
int partition(int *a,int p,int q)
{
int temp,x=a[p];
int i=p;
#pragma omp for
for (int j=p+1;j<=q;j++)
{
	if (a[j]<=x)
	{
	i++;
	temp=a[i];
	a[i]=a[j];
	a[j]=temp;
	
	}
}
temp=a[p];
a[p]=a[i];
a[i]=temp;
return i;
}
void quicksort(int *a,int p,int q)
{
if(p<q)
{
int r=partition(a,p,q);
quicksort(a,p,r-1);
quicksort(a,r+1,q);
}
}
int main()
{
int *a,n;
cout<<"Enter number of elements in array : ";
cin>>n;
a=new int(n);
cout<<"Enter "<<n<<" elements \n" ; 
for(int i=0;i<n;i++)
{

cin>>a[i];
}
quicksort(a,0,n-1);
cout<< "Sorted List is : \n";
for(int i=0;i<n;i++)
{

cout<<a[i]<<endl;
}
return 0;
}

/*


student@ubuntu:~$ g++ Quicksort.cpp 
student@ubuntu:~$ ./a.out
Enter number of elements in array : 10
Enter 10 elements 
99
41
25
49
63
85
66
25
10
6
Sorted List is : 
6
10
25
25
41
49
63
66
85
99
*/
