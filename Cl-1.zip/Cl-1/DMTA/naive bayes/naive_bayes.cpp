/*
 * naive_bayes.cpp
 *
 *  Created on: 21-Aug-2015
 *      Author: student
 */

#include<iostream>
using namespace std;

typedef struct table{
	int RID;
	int age;
	int income;
	bool stud;
	int cr;
	bool buy;
}table1;
int main() {
	int rno;
	char ch;
	cout<<"Enter No. of records in table";
	cin>>rno;
	table1 *X=new table1[rno];
	for(int i=0;i<rno;i++){
		cout<<"Enter record for RID "<<i+1<<" of table\n";
		X[i].RID=i+1;
		do{
			cout<<"Age : 1.Infant\t2.Young\t3.Old\n";
			cin>>X[i].age;
			if(X[i].age>3 || X[i].age<1){
				cout<<"Plz enter correct age\n";
			}
		}while(X[i].age>3 || X[i].age<1);
		do{
			cout<<"Income : 1.Low\t2.Medium\t3.High\n";
			cin>>X[i].income;
			if(X[i].income>3 || X[i].income<1){
				cout<<"Plz enter correct income\n";
			}
		}while(X[i].income>3 || X[i].income<1);
		cout<<"Weather he/she is student(1-Yes & 0-No):";
		cin>>X[i].stud;
		do{
			cout<<"Creadit Rating : 1.Low\t2.Fair\t3.High\n";
			cin>>X[i].cr;
			if(X[i].cr>3 || X[i].cr<1){
				cout<<"Plz enter correct income\n";
			}
		}while(X[i].cr>3 || X[i].cr<1);
		cout<<"Weather he/she buy the computer(1-Yes & 0-No):";
		cin>>X[i].buy;
	}
	cout<<"| RID\t| Age\t| Income|Student| Creadit_Rating| Buy\t|\n";
	for(int i=0;i<rno;i++){
		cout<<"| "<<X[i].RID<<"\t| ";
		switch(X[i].age){
		case 1:cout<<"Infant| ";break;
		case 2:cout<<"Young\t| ";break;
		case 3:cout<<"Old\t| ";break;}
		switch(X[i].income){
		case 1:cout<<"Low\t| ";break;
		case 2:cout<<"Medium| ";break;
		case 3:cout<<"High\t| ";break;}
		if(X[i].stud){cout<<"Yes\t| ";}
		else{cout<<"No\t| ";}
		switch(X[i].cr){
		case 1:cout<<"Low\t\t| ";break;
		case 2:cout<<"Fair\t\t| ";break;
		case 3:cout<<"High\t\t| ";break;}
		if(X[i].buy){cout<<"Yes\t| ";}
		else{cout<<"No\t| ";}
		cout<<endl;

	}
	int yes=0,no=0;
	for(int i=0;i<rno;i++){
		if(X[i].buy){
			yes++;
		}
		else{
			no++;

		}
	}
	float pbyes=(float)yes/rno,pbno=(float)no/rno;
	cout<<"P(buy_comp=Yes)="<<pbyes<<endl;
	cout<<"P(buy_comp=No)="<<pbno<<endl;
	
	int c,f,t,pn=0,pno=0;
	float py[20],pn1[20],s;
	int tf;
	do{
		t=0;
		cout<<"Enter critera for conditional probability :\n";
		cout<<"1-Buy Computer & 0-Not Buy Computer ";
		cin>>tf;
		cout<<"1.Age\t2.Income\t3.Student\t4.Credit Rating";
		cin>>c;
		switch (c)
		{
		case 1:
			do{
			cout<<"Enter Field of Age: 1.Infant\t2.Young\t3.Old\n";
			cin>>f;
			}while(f>3 || f<1);
			for(int i=0;i<rno;i++){
				if(X[i].age==f && X[i].buy==tf){
					t++;
				}
			}
			(tf==1)?s=py[pn++]=(float)t/yes:s=pn1[pno++]=(float)t/no;
			switch(f){
			case 1:cout<<"P(Age=Infant|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
			case 2:cout<<"P(Age=Young|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
			case 3:cout<<"P(Age=Old|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
				
			}
			break;
		case 2:
			do{
			cout<<"Enter Field of Income : 1.Low\t2.Medium\t3.High\n";
			cin>>f;
			}while(f>3 || f<1);
			for(int i=0;i<rno;i++){
				if(X[i].income==f && X[i].buy==tf){
					t++;
				}
			}
			(tf==1)?s=py[pn++]=(float)t/yes:s=pn1[pno++]=(float)t/no;
			switch(f){
			case 1:cout<<"P(Income=Low|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
			case 2:cout<<"P(Income=Medium|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
			case 3:cout<<"P(Income=High|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
				
			}
			break;
		case 3:
			do{
			cout<<"Enter Field of Student: 1.Yes\t0.No";
			cin>>f;
			}while(f!=0 && f!=1);
			for(int i=0;i<rno;i++){
				if(X[i].stud==f && X[i].buy==tf){
					t++;
				}
			}
			(tf==1)?s=py[pn++]=(float)t/yes:s=pn1[pno++]=(float)t/no;
			switch(f){
			case 1:cout<<"P(Student=Yes|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
			case 2:cout<<"P(Student=No|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
			
			}
			break;
		case 4:
			do{
			cout<<"Enter Field of Creadit Rating : 1.Low\t2.Fair\t3.High";
			cin>>f;
			}while(f>3 || f<1);
			for(int i=0;i<rno;i++){
				if(X[i].cr==f && X[i].buy==tf){
					t++;
				}
			}
			(tf==1)?s=py[pn++]=(float)t/yes:s=pn1[pno++]=(float)t/no;
			switch(f){
			case 1:cout<<"P(Creadit_rating=Low|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
			case 2:cout<<"P(Creadit_rating=Fair|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
			case 3:cout<<"P(Creadit_rating=High|buys_computer=";
				(tf==1)?cout<<"Yes":cout<<"No";
				cout<<") = "<<s<<endl;
				break;
				
			}
			break;
		default:
			break;
		}
		t=0;
		cout<<"Press Y for more conditional probabilities:";
		cin>>ch;
	}while(ch=='y'||ch=='Y');

	float fproy=1,fpron=1;
	for(int i=0;i<pn;i++){
		fproy=fproy*py[i];
	}
	cout<<"P(X|buys_computer=Yes)="<<fproy<<endl;
	fproy=fproy*pbyes;
	for(int i=0;i<pno;i++){
		fpron=fpron*pn1[i];
	}
	cout<<"P(X|buys_computer=No)="<<fpron<<endl;
	fpron=fpron*pbno;
	cout<<"P(buys_computer=Yes)="<<fproy<<endl;
	cout<<"P(buys_computer=No)="<<fpron<<endl;
	return 0;
}

