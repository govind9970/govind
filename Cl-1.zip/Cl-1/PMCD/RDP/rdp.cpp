#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<cctype>
static char buffer[30];
int i=0;
void S();
void E();
void T();
void T1();
void F();
void A();
void E1();
static int flag=0;

void A()
{
	if(isalnum(buffer[i]))
	{
		flag=0;
		i++;
		
		while(isalnum(buffer[i]))
		{
			i++;
		}
	}
	else
	{
		printf("Error condition\n");
		exit(0);
	}
}
void E()
{
	T();
	E1();
}
void  E1()
{
	if(buffer[i]=='+')
	{
		flag=1;
		i++;
		T();
		E1();
	}
}
void T()
{
	F();
	T1();

}
void  T1()
{
	if(buffer[i]=='*')
	{
	        flag=1;
		i++;
		F();
		T1();
	}	
}
void F()
{
	if(buffer[i]=='(')
	{	
		flag=1;
			i++;
			E();
			if(buffer[i]==')')
			{
				
				i++;
				flag=0;
			}
			else
			{
				printf("Error condition\n");
				exit(0);
			}
			return;
	}
	A();


}
int main()
{

	printf("Enter input string: ");
	gets(buffer);
	
	E();
	
	if(buffer[i]==')')
		{
		flag=1;
		printf("Error condition\n");
		exit(0);	
		}
	if(flag==0)
	printf("\nIt is a valid string\n");
	return 0;
}

/*
student@ubuntu:~$ gcc rdp.cpp
student@ubuntu:~$ ./a.out
Enter input string: id+id*id;

It is a valid string
student@ubuntu:~$ ./a.out
Enter input string: (a+b*c
Error condition
*/

